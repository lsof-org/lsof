typedef struct cnode {
        udecl_simple_lock_data(, c_statelock)   /* 8: cnode field lock */
        u_int            c_flags;       /* 4: flags, see below */
        time_t           c_toktime;     /* 4: Time of last activity */
        struct cnode    *c_hash;        /* 8: cnode hash chain */
        /*
         * If c_hp exists then c_fh and c_hp->sct_fh point
         * to the same storage.  On client, cinactive will
         * deallocate filehandle storage; on server filehandle
         * storage is deallocated by SVRTOK_DESTROY.
         */
        cfhandle_t      *c_fh;          /* 8: File handle */
        svrcfstok_t     *c_hp;          /* 8: Hash pointer */

        /* --------------------64 byte boundary--------------------------*/

        union {
                daddr_t C_nextr;        /* 8: VREG: next read-ahead offset */
                off_t   C_lastcookie;   /*    VDIR: last readdir cookie */
        } c_c;
#define c_nextr          c_c.C_nextr
#define c_lastcookie     c_c.C_lastcookie

        vattr_t          c_attr;        /* 96:Cached vnode attributes */
        cred_t          *c_cred;        /* 8: creds - cfs/nfs-client only */
        access_cache    *c_acc;         /* 8: cache of access results */
        u_int            c_wopncnt;     /* 4: Write open count */
        u_int            c_ropncnt;     /* 4: Read open count */

        /* --------------------64 byte boundary--------------------------*/

        lock_data_t      c_rwlock;      /* 48: Read/write cnode lock */
        union {
                int     *D_dnlclist;    /* 8: VDIR: ptr to lookup hash values */
                void    *D_diomap;      /*    VREG: ptr to directio xtnt map */
        } c_d;
#define c_dnlclist c_d.D_dnlclist
#define c_diomap   c_d.D_diomap

        caddr_t          c_symlink;     /* 8: Cached symlink (remote only) */

        /* --------------------64 byte boundary--------------------------*/

#ifdef TNC_EXNFS

        struct timeval   c_cachetime;   /* 8: time caches become invalid */
        u_int            c_gen;         /* 4: generation for attr cache */
        u_int            c_dgen;        /* 4: generation for data cache */
#endif

        /*
         * Tokens.
         */
        CLITOK_T         c_tcblock;     /* 24: lock for tokens */
        u_long           c_tokmask;     /* 8:  bits mask of existing tokens  */
        tokens_t        *c_tokens;      /* 8:  tokens */
        char            *c_filename;    /* 8: Saved component name  */

        /* --------------------64 byte boundary--------------------------*/

#ifdef TOKEN_LOGGING
        thread_t         c_threadid;    /* 8: sleeping thread in token code */
        char            *c_place;       /* 8: where c_threadid is in token code */
#endif /* TOKEN_LOGGING */
        int              c_error;       /* 4: async write error */
        int              c_delaylen;    /* 4: Length of delay write cluster */
        off_t            c_delayoff;    /* 8: Start of delay write cluster */
        int              c_activedio;   /* 4: Count of active dio ops */
} cnode_t;
