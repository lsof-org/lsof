/*
 * kaddrtst.c -- make kernel virtual memory address validation tests
 *
 * V. Abell <abe@purdue.edu>
 * May 2000
 */

/*
 * Compile with:
 *
 *	cc kaddrtst.c -o kaddrtst -lelf -lkvm
 *
 * Run with:
 *
 *	./kaddrtst
 */

#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>
#include <nlist.h>
#include <kvm.h>
#include <vm/as.h>

struct nlist Nl[] = {
	{ "kas", 0, 0, 0, 0, 0 },
	{ "", 0, 0, 0, 0, 0 }
};

extern u_longlong_t kvm_physaddr(kvm_t *, struct as *, u_int);

main()
{
	int i;
	kvm_t *kvm;
	struct as kas;
	u_longlong_t pa;
	u_int va[]  = { 0, 0x657a682e, 0 };
/*
 * Get the address of the kernel's address space structure for the
 * kvm_physaddr() funcion.
 */
	if (nlist("/dev/ksyms", Nl)) {
	    perror("nlist");
	    exit(1);
	}
	if (!Nl[0].n_value) {
	    (void) fprintf(stderr, "%s: no address\n", Nl[0].n_name);
	    exit(1);
	}
/*
 * Open KVM access and read the kernel's address space structure.
 */
	if (!(kvm = kvm_open(NULL, NULL, NULL, O_RDONLY, NULL))) {
	    perror("kvm_open");
	    exit(1);
	}
	if (kvm_read(kvm, (unsigned long)Nl[0].n_value, (char *)&kas,
		     sizeof(kas))
	!= sizeof(kas))
	{
	    (void) fprintf(stderr, "can't read: %s\n", Nl[0].n_name);
	    exit(1);
	}
/*
 * Set the kernel's address space structure virtual address as the first
 * virtual test address.  The second virtual test address will be the virtual
 * address of the qfe register that lsof read and cause a kernel panic.
 *
 * NOTE: LSOF DOESN'T TRY TO READ EITHER VIRTUAL ADDRESS -- IT ONLY SUBMITS
 * THEM TO kvm_physaddr() FOR TRANSLATION.
 *
 * The kernel's address space structure virtual address should translate to a
 * physical address, while the qfe's register virtual address should have no
 * physical counterpart.
 */
	va[0] = (u_int)Nl[0].n_value;
	for (i = 0; va[i]; i++) {
	    pa = kvm_physaddr(kvm, &kas, va[i]);
	    (void) fprintf(stderr, "virtual %#x: ", va[i]);
	    if (pa == (u_longlong_t)-1)
		(void) fprintf(stderr, "has no physical counterpart\n");
	    else
		(void) fprintf(stderr, "is physical %#llx\n", pa);
	}
	return(0);
}
