/*
 * From Andrew Kephart of IBM -- for possible future AIX Configure
 * script and source code use.
 *
 * Vic Abell, 21 October 1999
 */

#include <stdio.h>

extern struct {
	int padding[31];
    int kernel;     /* kernel attributes                */
} _system_configuration;


int
main()
{
#ifdef __64BIT__
	printf("App: 64 ");
#else /* !__64BIT__ */
	printf("App: 32 ");
#endif /* __64BIT__ */
	if (_system_configuration.kernel & 0x01) printf("Kern: 64\n");
	else printf("Kern: 32\n");
	exit(0);
}


