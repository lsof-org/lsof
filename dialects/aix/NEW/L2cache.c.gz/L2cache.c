#include <stdio.h>
#include <sys/systemcfg.h>

int main (int argc, char *argv[]) {
  int arch;
  int imp;
  int width;
  char *carch, *cimp;

  arch = _system_configuration.architecture;
  imp = _system_configuration.implementation;
  width = _system_configuration.width;

  carch = cimp = "undetermined";

  if (arch == POWER_RS) carch = "POWER" ;
  if (arch == POWER_PC) carch = "PowerPC" ;

  if (imp == POWER_RS1) cimp = "POWER_RS1" ;
  if (imp == POWER_RSC) cimp = "POWER_RSC" ;
  if (imp == POWER_RS2) cimp = "POWER_RS2" ;
  if (imp == POWER_601) cimp = "Power601" ;
  if (imp == POWER_603) cimp = "Power603" ;
  if (imp == POWER_604) cimp = "Power604" ;
  if (imp == POWER_620) cimp = "Power620" ;
 
  printf ("Architecture is %s ;  Implementation is %s\n", carch, cimp) ;

  printf ("%6d I-cache\t%6d D-cache\t%10d L2 cache\t%d-bit words\n"
	,_system_configuration.icache_size
	,_system_configuration.dcache_size
	,_system_configuration.L2_cache_size
	,width
  );
  
  }
