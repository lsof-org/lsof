#include <stdio.h>
#include <fcntl.h>

/* int kread(u_longlong_t addr, char *buf, int len); DEBUG */

int Kd = -1;

int
main()
{
	char buf[64];

	if ((Kd = open("/dev/kmem", O_RDONLY, 0)) < 0) {
	    perror("open kmem");
	    return(1);
	}
	/* (void) kread((u_longlong_t)0, buf, (int)sizeof(buf)); DEBUG */ /* legitimate */
	(void) read(0, buf, sizeof(buf));
	return(0);
}

/* DEBUG
int kread(u_longlong_t addr, char *buf, int len)
{
	static int ft = 1;
	if (ft) {
	    (void) fprintf(stderr, "kread: first call\n");
	    ft = 0;
	    return;
	}
	fprintf(stderr, "DEBUG: kread() was called!!!\n");
}
DEBUG */
