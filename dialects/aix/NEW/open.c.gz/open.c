/*
 * open.c -- test program to show files open to a process immediately
 *	     after execution begins
 *
 * V. Abell <abe@purdue.edu>
 * Purdue University Computing Center
 */

/*
 * Compile: cc open.c -o open
 *
 * Execute: ./open
 *
 * Any open FDs other thatn 0, 1, and 2 are abnormal.
 */

#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>

extern int errno;

main() {
	int fd, nd;
	struct stat sb;

	nd = getdtablesize();
	(void) printf("%d FDs open\n", nd);
	for (fd = 0; fd < nd; fd++) {
	    if (fstat(fd, &sb)) {
		if ((errno = EBADF) || (errno == ENOENT))
		    continue;
		(void) printf("%8d: %s\n", fd, strerror(errno));
	    } else {
		(void) printf("%8d: open, dev=%#lx, ino=%ld\n", fd,
		    (long)sb.st_dev, (long)sb.st_ino);
	    }
	}
	exit(0);
}
