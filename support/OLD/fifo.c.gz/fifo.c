#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#define	MESSAGE	"hello world\n"
#define	PATHNM	"imafifo"

main(argc, argv)
	int argc;
	char *argv[];
{
	char buf[128];
	int fd, len, mode, wr;
	struct stat sb;

	if (stat(PATHNM, &sb) != 0) {
		if(mknod(PATHNM, 0644 | S_IFIFO, 0) != 0) {
			perror("mknod");
			exit(1);
		}
		fprintf(stderr, "created: %s\n", PATHNM);
	}
	if (argc > 1) {
		mode = O_RDWR;
		fprintf(stderr, "opening O_RDWR: %s\n", PATHNM);
	} else {
		mode = O_RDONLY;
		fprintf(stderr, "opening O_RDONLY: %s\n", PATHNM);
	}
	if ((fd = open(PATHNM, mode, 0644)) < 0) {
		perror("open");
		exit(1);
	}
	fprintf(stderr, "%s open for %sing\n", PATHNM,
		(mode == O_RDONLY) ? "read" : "writ");
	if (mode == O_RDWR) {
		(void) strcpy(buf, MESSAGE);
		len = strlen(buf);
		buf[len++] = '\0';
		if ((wr = write(fd, buf, len)) != len) {
			if (wr < 0)
				perror("write");
			else
				fprintf(stderr, "wrote %d of %d\n", wr, len);
			exit(1);
		}
	}
	fprintf(stderr, "sleeping\n");
	(void) sleep(3600);
	exit(0);
}
