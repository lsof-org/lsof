#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define	INFSLEEP	24*60*60
#define	SLEEPTM		300
#define	SOCKNM		"unix_socket_name"

main(int argc, char *argv[])
{
	int s;
	int stm = SLEEPTM;
	struct sockaddr_un u;

	(void) unlink(SOCKNM);
	if ((s = socket(AF_UNIX, SOCK_STREAM, 0)) < 0) {
		perror("socket");
		exit(1);
	}
	u.sun_family = AF_UNIX;
	(void) strcpy(u.sun_path, SOCKNM);
	if (bind(s, (struct sockaddr *)&u, sizeof(u)) < 0) {
		perror("bind");
		exit(1);
	}
	if (argc > 1) {
		if (strcmp(argv[1], "-i") == 0)
			stm = INFSLEEP;
		else
			stm = atoi(argv[1]);
	}
	fprintf(stderr, "sleeping for %d seconds\n", stm);
	if (stm)
		sleep(stm);
	(void) unlink(SOCKNM);
	exit(0);
}
