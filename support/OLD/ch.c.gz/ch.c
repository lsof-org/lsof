#include <stdio.h>
#include <sys/file.h>

extern int errno;

main(int argc, char *argv[])
{
	int fd;
	unsigned char nm[16];

	(void) strcpy(nm, "test.file");
	nm[4] = (unsigned char)0xe4;
	if ((fd = open((char *)nm, O_RDWR|O_CREAT, 0644)) < 0) {
	    fprintf(stderr, "open(%s): %s\n", nm, strerror(errno));
	    exit(1);
	}
	exit(0);
}
