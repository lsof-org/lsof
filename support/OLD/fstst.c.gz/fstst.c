/*
 * NAME
 *	namefs1.c - check basic use of namefs pipe
 *
 * CALLS
 *	fattach, read, write, fdetach
 *
 * ALGORITHM
 *	Open a pipe and fattach to a name in the filesystem name space.
 *	Check that read and write work.  Then detach the pipe and close.
 *
 *
 * $Copyright: $
 * Copyright (c) 1984, 1985, 1986, 1987, 1988, 1989, 1990, 1991, 1992, 1993, 1994
 * Sequent Computer Systems, Inc.   All rights reserved.
 *  
 * This software is furnished under a license and may be used
 * only in accordance with the terms of that license and with the
 * inclusion of the above copyright notice.   This software may not
 * be provided or otherwise made available to, or used by, any
 * other person.  No title to or ownership of the software is
 * hereby transferred.
 */

#ifndef lint
static char rcsid[]= "$Header: namefs1.c 1.1 1993/04/28 18:52:48 $";
#endif

#include <stdio.h>		/* needed by testhead.h		*/
#include <sys/errno.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/errno.h>
#include <fcntl.h>
#include <signal.h>

#define	STRLEN	26

extern int errno;
extern int local_flag ;   	
char PIPE[100];
char progname[] = "namefs1()" ;

main()
{
	int filefd, pipefd;
	int fildes[2];
	char readbuf[BUFSIZ], writebuf[BUFSIZ];
	char *wrstr = "abcdefghijklmnopqrstuvwxyz";
	char *rdstr = "zyxwvutsrqponmlkjihgfedcba";
	int red, written, retval;
	struct stat statbuf;

	sprintf(PIPE, "./namefs1.%d.1", getpid());
	unlink(PIPE);

	filefd = open(PIPE, O_RDWR | O_CREAT, 0640);
	if (filefd < 0) {
		fprintf(stderr, "\tOpen of file failed, errno: %d\n", errno);
		exit(1);
	}

	if (stat(PIPE, &statbuf) != 0) {
		fprintf(stderr, "\tStat failed, errno: %d\n", errno);
		exit(1);
	} else {
		if ((statbuf.st_mode & S_IFIFO) != 0) {
			fprintf(stderr, "\tMode 1 is not regular file.\n");
			exit(1);
		}
	}

	retval = pipe(fildes);
	if (retval < 0) {
		fprintf(stderr, "\tPipe call failed, errno: %d\n", errno);
		exit(1);
	}
	
	retval = fattach(fildes[0], PIPE);
	if (retval < 0) {
		fprintf(stderr, "\tFattach failed, errno: %d\n", errno);
		exit(1);
	}
	close(fildes[0]);

	if (stat(PIPE, &statbuf) != 0) {
		fprintf(stderr, "\tStat failed, errno is %d\n", errno);
		exit(1);
	} else {
		if ((statbuf.st_mode & S_IFIFO) != 0) {
			fprintf(stderr, "\tMode 2 is not regular file.\n"); 
/*			exit(1);	VAA */
		}
	}

	pipefd = open(PIPE, O_RDWR);
	if (pipefd < 0) {
		fprintf(stderr, "\tOpen fattach file failed, errno %d\n", errno);
		exit(1);
	}
	fprintf(stderr, "VAA: sleeping\n");
	sleep(84400); /* VAA */
	exit(0);
}
