static char sccsid[] = "@(#)42	1.15  com/sys/proc/getproc.c, bos 1/21/91 19:03:43";
/*
 * COMPONENT_NAME: SYSPROC
 *
 * FUNCTIONS: getargs(), getproc(), getuser(), getevars()
 *
 * ORIGIN: 27
 *
 * IBM CONFIDENTIAL
 * Copyright International Business Machines Corp. 1988, 1989
 * Unpublished Work
 * All Rights Reserved
 * Licensed Material - Property of IBM
 *
 * RESTRICTED RIGHTS LEGEND
 * Use, Duplication or Disclosure by the Government is subject to
 * restrictions as set forth in paragraph (b)(3)(B) of the Rights in
 * Technical Data and Computer Software clause in DAR 7-104.9(a).
 */

#include <sys/param.h>
#include <sys/types.h>
#include <sys/user.h>
#include <sys/errno.h>
#include <sys/proc.h>
#include <sys/lockl.h>
#include <procinfo.h>
#include <execargs.h>
#include <sys/low.h>
#include <sys/syspest.h>
#include <sys/pseg.h>
#include <sys/reg.h>
#include <sys/vmker.h>

/* GLOBAL VARIABLES */
extern int	copyin();	   /* copies from user to kernel	    */	
extern int	copyout();	   /* copies from kernel to user	    */	
extern int	subyte();	   /* set byte in user space with spec value*/
extern caddr_t	vm_att();	   /* attaches to segment		    */
extern void	vm_det();	   /* deattaches from to segment	    */
extern int	xmattach();	   /* fills out cross memory descriptor	    */
extern int	xmemin();	   /* copies data from one seg to another   */
extern int	xmdetach();	   /* decrements reference count to segment */
extern struct	proc *max_proc;	   /* kernel proc high water mark	    */

/* LOCAL VARIABLES */
static void 	userinfo_in();

#define    GETUSER_NONE       0    /* invalid argument                      */
#define    GETUSER_USERINFO   1    /* getuser() returns userinfo structure  */
#define    GETUSER_USER       2    /* getuser() returns user     structure  */
#define    NANOTOMICRO        1000 /* converts nanoseconds to microseconds  */

#define    UPDATE_RUSAGE( m, c )                                  \
                     (m)->ru_majflt = p->p_majflt;                \
                     (m)->ru_minflt = p->p_minflt;                \
                     (m)->ru_utime.tv_usec /= NANOTOMICRO;        \
                     (m)->ru_stime.tv_usec /= NANOTOMICRO;        \
                     (c)->ru_utime.tv_usec /= NANOTOMICRO;        \
                     (c)->ru_stime.tv_usec /= NANOTOMICRO

/*
 * NAME: getproc()
 *
 * FUNCTION: Retrieves an image of the process table
 *
 * EXECUTION ENVIRONMENT: This routine may only be called by a process
 *                        This routine may page fault
 *
 * NOTES: The table is not guaranteed to be consistent, though individual proc
 *        entries are consistent.  Uses max_proc as the high water mark.
 *
 * RETURN VALUES:
 *	number	active processes retrieved
 *      -1	failed, errno indicates cause of failure
 */
getproc(struct procinfo *procinfo, int nproc, int sizproc)
/* struct  procinfo *procinfo;	 pointer to array of procinfo struct	*/
/* int	nproc;			 number of user procinfo struct	*/
/* int	sizproc;		 size of expected procinfo structure	*/
{

	register struct proc *p;	/* pointer to kernel proc table	*/
	struct procinfo *procinfo0 = procinfo; 	/* storage for start	*/
	struct procinfo procloc;	/* temp storage, proc entries	*/
	register struct procinfo *proclocp = &procloc;	/* temp pointer	*/
	register int waslocked;		/* remember lockl return code	*/
	register int num_act = 0;	/* counter of active processes	*/
	unsigned long tsz;		/* virtual size of text segment */ 
	unsigned long dsz;		/* virtual size of data segment */ 
	struct user *uptr;		/* pointer to the uarea 	*/

	assert(csa->prev == NULL);	/* make sure this is a process	*/
	if (sizproc != sizeof(struct procinfo))	/* parameter ok		*/
	{
		u.u_error = EINVAL;
		return(-1);
	}
	if (nproc <= 0)	/* if invalid nproc, set 1st pid to maximum	*/
	{
		proclocp->pi_pid = ((int)max_proc - (int)proc) /
							sizeof(struct proc);
		if (copyout((caddr_t)&proclocp->pi_pid,
			(caddr_t)&procinfo0->pi_pid, sizeof(proclocp->pi_pid)))
		{
       			u.u_error = EFAULT;
			return(-1);
		}
		u.u_error = ENOSPC;
		return(-1);
	}
	/* walk through the proc table till max_proc high water mark	*/
	for (p = &proc[0]; p < max_proc; p++)
	{
		waslocked = lockl(&proc_lock, LOCK_SHORT);	/* lock	*/
		if (p->p_stat != SNONE && ++num_act <= nproc)
		{
			proclocp->pi_pid = p->p_pid;	/* process ID	*/
			proclocp->pi_ppid = p->p_ppid;	/* parent ID	*/
			proclocp->pi_uid = p->p_uid;	/* real user ID	*/
			proclocp->pi_suid = p->p_suid;	/* save user ID	*/
			proclocp->pi_pgrp = p->p_pgrp;	/* process grp	*/
			proclocp->pi_sid = p->p_sid;	/* session ID	*/
			proclocp->pi_pri = p->p_pri;	/* priority	*/
			proclocp->pi_nice = EXTRACT_NICE(p); /* nice value*/
			proclocp->pi_cpu = MIN(P_CPU_MAX,p->p_cpu);/* cpu 
							usage */
			proclocp->pi_flag = p->p_flag;	/* cpu flag	*/
			proclocp->pi_stat = p->p_stat;	/* proc state	*/
			proclocp->pi_wchan = p->p_wchan;/* wait channel */
			proclocp->pi_wtype = p->p_wtype;/* wait type */
			proclocp->pi_adspace = p->p_adspace; /* addr */
			proclocp->pi_utime = p->xp_utime; /* user time	*/
			proclocp->pi_stime = p->xp_stime; /* system time */
			proclocp->pi_majflt = p->p_majflt; /* i/o page fault */
			proclocp->pi_minflt = p->p_minflt; /* non i/o pfault */
			proclocp->pi_size = 0; 		     /* process size */

			if ( p->p_stat != SZOMB && !(p->p_flag & SEXIT)){

				/* 
			 	 * Calculate process size by requesting the
				 * number of pages that have been accessed
				 * in the text and data segments.
				 */
				uptr = (struct user *)vm_att(p->p_adspace, &u);
				dsz=vms_psusage(uptr->u_adspace.srval[PRIVSEG]);
				tsz=vms_psusage(uptr->u_adspace.srval[TEXTSEG]);
				(void)vm_det((caddr_t)uptr);

				proclocp->pi_size = btoc((dsz + tsz)*PAGESIZE);
			}

			if (waslocked != LOCK_NEST)	/* unlock proc	*/
				unlockl(&proc_lock);

			/* protected copy to user space, checks perm	*/
			if (copyout((caddr_t)proclocp, (caddr_t)procinfo++,
								sizproc))
			{
	       			u.u_error = EFAULT;
				return(-1);
			}
		}
		else
		{
			if (waslocked != LOCK_NEST)	/* unlock	*/
				unlockl(&proc_lock);
		}
	}
	/*
	 * check to see if there are more active processes than user space
	 * if so, then load user procinfo[0].pid with actual number
	 * and return error condition
	 */
	if (num_act > nproc)
	{
		proclocp->pi_pid = num_act;
		if (copyout((caddr_t)&proclocp->pi_pid,
			(caddr_t)&procinfo0->pi_pid, sizeof(proclocp->pi_pid)))
		{
       			u.u_error = EFAULT;
			return(-1);
		}
		u.u_error = ENOSPC;
		return(-1);
	}
	return(num_act);	/* successful, return no. active entries */
}


/*
 * NAME: getargs()
 *
 * FUNCTION: Retrieves the arguments for a process found via getproc()
 *
 * EXECUTION ENVIRONMENT: This routine may only be called by a process
 *                        This routine may page fault
 *
 * NOTES: The table is not guaranteed to be consistent
 *
 * RETURN VALUES:
 *	 0	active processes retrieved
 *	-1	failed, errno indicates cause of failure, the first byte
 *	  	of args is set to NULL.
 */
getargs(struct procinfo *procinfo, int plen, char *args, int alen)
/* struct  procinfo *procinfo;	 pointer to array of procinfo struct	*/
/* int	plen;			 size of expected procinfo struct	*/
/* char	*args;			 pointer to user array for arguments	*/
/* int	alen;			 size of expected argument array	*/
{
	struct procinfo procloc;	/* temp storage, proc entries	*/
	struct procinfo *proclocp = &procloc;	/* temp pointer		*/
	struct proc 	*p;		/* process struct pointer	*/
	int 		cnt = 2;	/* char count for transfers	*/
	char 		**argv;		/* argv for user process	*/
	char 		*argvp;		/* char pointer array pointer	*/
	int 		prclkold;	/* remember lockl return code	*/
	caddr_t 	dptr;		/* ptr to the specified uarea   */
	int 		rc = XMEM_SUCC;	/* return flag 			*/
	struct xmem	dp;		/* cross memory descriptor      */
	char 		c;		/* trusted dest for user data   */

	assert(csa->prev == NULL);	/* make sure this is a process	*/

	/* check parameters for valid struct sizes:  plen, alen		*/
	if (plen != sizeof(struct procinfo) || alen < 2)
	{
		u.u_error = EINVAL;
		return(-1);
	}
	/* 
	 * Initialize the output variable, "args", which is composed of
	 * multiple strings.  Each of which is terminated by a NULL 
	 * character as is the entire set of strings.
	 */
	if (subyte(args, NULL) != 0)
	{
       		u.u_error = EFAULT;
		return(-1);
	}
	if (subyte(args+1, NULL) != 0)
	{
       		u.u_error = EFAULT;
		return(-1);
	}
	if (copyin((caddr_t)procinfo, (caddr_t)proclocp, sizeof(procloc)))
	{
		u.u_error = EFAULT;
		return(-1);
	}
	
	prclkold = lockl(&proc_lock, LOCK_SHORT);	/* proc lock	  */

	/* check to see if the process is still active & the same pid	  */
	if ( (p = VALIDATE_PID(proclocp->pi_pid)) && 
	    !(p->p_stat == SNONE || p->p_stat == SZOMB) && 
	    !(p->p_flag & (SEXIT | SKPROC)) )
	{
		/*
		 * Attach to user segment, setup cross-memory descriptor,
		 * then detach from segment.  This segment can be detached,
		 * because xmemin() attaches and detaches each time it 
		 * copies from the source segment.  The cross-memory services
		 * are used because they provide exception handling, and
		 * because the source segment is not deduced from the current 
		 * processes address space. 
		 */
		dptr = vm_att(p->p_adspace, 0);
		dp.aspace_id = XMEM_INVAL;
		(void)xmattach(dptr, sizeof(int), &dp, SYS_ADSPACE);
		(void)vm_det(dptr);  

		/* 
		 * Copy applications main() parameter char **argv from user 
		 * stack, which is passed to the application in register 4, 
		 * and which is saved at the top of the stack.  
		 */
		if ((rc=xmemin(ARGS_loc, &argv, sizeof(argv),&dp)) == XMEM_SUCC)
		{
			rc = xmemin(argv++, &argvp, sizeof(argvp), &dp);
		}

		/* 
		 * Fetch a byte at a time from the specified process. 
		 * xmemin truncates the top four bits, so the offsets are
		 * recomputed relative to the vmattach()ed segment.
		 */
		while (  argvp != NULL && 
			(cnt <= alen || cnt <= NCARGS) && 
			 rc == XMEM_SUCC  )
		{
			do
			{
				/* overflow user area or exceed sys max	  */
				if (cnt == alen || cnt == NCARGS)
				{
					if (subyte(args++, '\0') != 0)
					{
       						rc = XMEM_FAIL;
					}
					break;
				}
				if ((rc = xmemin(argvp++,&c,sizeof(c),&dp)) == 
					XMEM_SUCC){
					if (subyte(args++, c) != 0)
					{
       						rc = XMEM_FAIL;
						break;
					}
					cnt++;
				}
			}
			while (c != '\0' && rc == XMEM_SUCC);
			if ( rc == XMEM_SUCC )
			{
				rc = xmemin(argv++, &argvp, sizeof(argvp), &dp);
			}
			cnt++;
		}
		if (subyte(args, NULL) != 0)
		{
       			rc = XMEM_FAIL;
		}
		if (rc != XMEM_SUCC)
		{
			rc = EFAULT; 
		}
		(void)xmdetach(&dp);
	}
	else 
	{
		/* if process does not exist */
		if (p->p_stat == SNONE || p->p_pid != proclocp->pi_pid)
		{
			rc = EBADF;
		}
	}

	if (prclkold != LOCK_NEST)		     /* release proc lock */
		unlockl(&proc_lock);

	if (rc != XMEM_SUCC)
	{
		u.u_error = rc;
		return(-1);
	}
	return(0);
}
/*
 * NAME: getevars()
 *
 * FUNCTION: Retrieves the environment for a process found via getproc()
 *
 * EXECUTION ENVIRONMENT: This routine may only be called by a process
 *                        This routine may page fault
 *
 * NOTES: The table is not guaranteed to be consistent
 *
 * RETURN VALUES:
 *	 0	active processes retrieved
 *	-1	failed, errno indicates cause of failure, the first byte
 *	  	of user_envp is set to NULL.
 */
int
getevars(struct procinfo *procinfo, int plen, char *user_envp, int alen)
/* struct  procinfo *procinfo;	pointer to array of procinfo struct	*/
/* int	plen;			size of expected procinfo struct	*/
/* char	*user_envp;		pointer to user array for environment	*/
/* int	alen;			size of expected environment array	*/
{
	struct procinfo procloc;	/* temp storage, proc entries	*/
	struct procinfo *proclocp = &procloc;	/* temp pointer		*/
	char 		**env;		/* env for user process		*/
	char 		*envp;		/* char pointer array pointer	*/
	int 		prclkold;	/* remember lockl return code	*/
	struct proc 	*p;		/* process struct pointer	*/
	caddr_t		dptr;		/* ptr to addr space of proc	*/
	TopOfStack 	*topstack; 	/* to get envp parms            */
	int 		cnt = 2;	/* char count for transfers	*/
	int 		rc = XMEM_SUCC;	/* return value flag		*/
	struct xmem	dp;		/* cross memory descriptor      */
	char 		c;		/* trusted dest for user data   */

	assert(csa->prev == NULL);	/* make sure this is a process	*/

	/* check parameters for valid struct sizes:  plen, alen		*/
	if (plen != sizeof(struct procinfo) || alen < 2)
	{
		u.u_error = EINVAL;
		return(-1);
	}
	/* 
	 * Initialize the output variable, "args", which is composed of
	 * multiple strings.  Each of which is terminated by a NULL 
	 * character as is the entire set of strings.
	 */
	if (subyte(user_envp, NULL) != 0)
	{
       		u.u_error = EFAULT;
		return(-1);
	}
	if (subyte(user_envp+1, NULL) != 0)
	{
       		u.u_error = EFAULT;
		return(-1);
	}
	if (copyin((caddr_t)procinfo, (caddr_t)proclocp, sizeof(procloc)))
	{
		u.u_error = EFAULT;
		return(-1);
	}
	
	prclkold = lockl(&proc_lock, LOCK_SHORT);	/* proc lock	*/

	/* check to see if the process is still active & the same pid	*/
	if (  (p = VALIDATE_PID(proclocp->pi_pid)) && 
	     !(p->p_stat == SNONE || p->p_stat == SZOMB) && 
	     !(p->p_flag & (SEXIT | SKPROC)))
	{
		/*
		 * Attach to user segment, setup cross-memory descriptor,
		 * then detach from segment.  This segment can be detached,
		 * because xmemin() attaches and detaches each time it 
		 * copies from the source segment.  The cross-memory services
		 * are used because they provide exception handling, and
		 * because the source segment is not deduced from the current 
		 * processes address space. 
		 */
		dptr = vm_att(p->p_adspace, 0);
		dp.aspace_id = XMEM_INVAL;
		(void)xmattach(dptr, sizeof(int), &dp, SYS_ADSPACE);
		(void)vm_det(dptr);  

		/* 
		 * Copy applications main() parameter char **argv from user 
		 * stack, which is passed to the application in register 4, 
		 * and which is saved at the top of the stack.  
		 */
		if ((rc= xmemin(ENVS_loc, &env, sizeof(env), &dp)) == XMEM_SUCC)
		{
			rc = xmemin(env++, &envp, sizeof(envp), &dp);
		}

		/* 
		 * Fetch a byte at a time from the specified process. 
		 * xmemin() truncates the top four bits, so the offsets are
		 * recomputed relative to the vmattach()ed segment.
		 */
		while (  envp != NULL && 
			(cnt <= alen || cnt <= NCARGS) && 
			 rc == XMEM_SUCC  )
		{
			do
			{
				/* overflow user area or exceed sys max	  */
				if (cnt == alen || cnt == NCARGS)
				{
					if (subyte(user_envp++, '\0') != 0)
					{
       						rc = XMEM_FAIL;
					}
					break;
				}
				if ((rc = xmemin(envp++,&c,sizeof(c),&dp)) == 
					XMEM_SUCC){
					if (subyte(user_envp++, c) != 0)
					{
       						rc = XMEM_FAIL;
						break;
					}
					cnt++;
				}
			}
			while (c != '\0' && rc == XMEM_SUCC);
			if ( rc == XMEM_SUCC )
			{
				rc = xmemin(env++, &envp, sizeof(envp), &dp);
			}
			cnt++;
		}
		if (subyte(user_envp, NULL) != 0)
		{
       			rc = XMEM_FAIL;
		}
		if (rc != XMEM_SUCC)
		{
			rc = EFAULT; 
		}
		(void)xmdetach(&dp);
	}
	else 
	{
		/* if process does not exist */
		if (p->p_stat == SNONE || p->p_pid != proclocp->pi_pid)
		{
			rc = EBADF;
		}
	}

	if (prclkold != LOCK_NEST)	/* release proc lock		*/
		unlockl(&proc_lock);
	if (rc != XMEM_SUCC)		
	{
		u.u_error = rc;
		return(-1);
	}
	return(0);
}


/*
 * NAME: getuser()
 *
 * FUNCTION: Return public information about processes found via getproc()
 *
 * EXECUTION ENVIRONMENT: This routine may only be called by a process
 *                        This routine may page fault
 *
 * NOTES: The table is not guaranteed to be consistent
 *
 * RETURN VALUES:
 *     0    process information retrieved
 *    -1    failed, errno indicates cause of failure
 */
getuser(struct procinfo *procinfo, int plen, void *user, int ulen)
/* struct  procinfo *procinfo;             ptr to array of procinfo struct
 * int     plen;                           size of expected procinfo struct
 * void   *user;                           ptr to userinfo struct OR user struct
 * int     ulen;                           size of expected userinfo struct
 */
{
   	struct procinfo	procloc;     	/* temp storage, proc entries         */
        struct procinfo *proclocp = &procloc; /* temp pointer                 */
   	struct proc     *p;            	/* process struct pointer             */
   	struct user     k_user;       	/* temporary user/userinfo struct     */
   	struct userinfo *k_userinfo;	/* temporary userinfo struct ptr      */
   	int             prclkold;	/* remember lockl return code         */
	int             status=0;	/* return status flag                 */
   	char            type;     	/* identifies user OR userinfo struct */
	struct user 	*uptr;		/* ptr to ublock of specified proc    */

   	assert(csa->prev == NULL);    /* make sure this is a process */

   	k_userinfo    = (struct userinfo *) &k_user;
   	type          = (ulen == sizeof(struct userinfo) ? GETUSER_USERINFO : 
        	         ulen == sizeof(struct user)     ? GETUSER_USER :
                	                                   GETUSER_NONE ) ;

   	/* check parameters for valid struct size: plen, ulen */
   	if ( plen != sizeof(struct procinfo) || type == GETUSER_NONE )
   	{
       		u.u_error = EINVAL;
       		return(-1);
   	}

   	if (copyin((caddr_t)procinfo, (caddr_t)proclocp, sizeof(procloc)))
   	{
       		u.u_error = EFAULT;
       		return(-1);
   	}

   	prclkold = lockl(&proc_lock, LOCK_SHORT);    /* proc lock    */

   	/* check to see if the process is still active & the same pid */
   	if ( (p = VALIDATE_PID(proclocp->pi_pid)) &&
	    !(p->p_stat == SNONE || p->p_stat == SZOMB) &&
            !(p->p_flag & SEXIT) )
   	{
		/* note vm_att truncates the top four bits */
		uptr = (struct user *)vm_att(p->p_adspace, &u);

       		if ( type == GETUSER_USER )
       		{
			bcopy(uptr, &k_user, sizeof(struct user));
           		UPDATE_RUSAGE( &k_user.u_ru, &k_user.u_cru );
       		}
       		else
       		{
			userinfo_in( k_userinfo, uptr );
               		UPDATE_RUSAGE( &k_userinfo->ui_ru, &k_userinfo->ui_cru);
       		}
		
		(void) vm_det((caddr_t)uptr);
   	}
   	else
       		status = EBADF;

   	if (prclkold != LOCK_NEST)    			/* release proc lock */
       		unlockl(&proc_lock);

   	if (status != 0)      	
   	{
       		u.u_error = EBADF;
       		return(-1);
   	}

   	/* use copyout() to transfer data to user area, perm checked */
   	if (copyout((caddr_t)&k_user, (caddr_t)user, ulen))
   	{
        	u.u_error = EFAULT;
        	return(-1);
   	}
   	return(0);

}

/*
 * NAME: userinfo_in()
 *
 * FUNCTION: copies userinfo struct from ublock anchored by uptr to kptr
 *
 * NOTES: The table is not guaranteed to be consistent
 *
 * RETURN VALUES:
 *     XMEM_SUCC   process information retrieved
 *     EBADF       failed, errno indicates cause of failure
 */
static void
userinfo_in( struct userinfo *kptr, struct user *uptr )
/* struct userinfo  *kptr;                 userinfo struct ptr                */
/* caddr_t          uptr;	           ptr to ublock of the specified proc*/
{
   	struct ucred    credentials;    /* temporary holder for process creds */
   	int             sreg_priv;      /* private segment register value     */
        int	        sreg_text;      /* text    segment register value     */
        int          	machine_frames; /* total num of page frames on machine*/
        int           	proc_frames;    /* total page frames used by process  */

	bcopy( uptr->u_cred,   &credentials,     sizeof(struct ucred));
	bcopy( uptr->u_rlimit,  kptr->ui_rlimit, sizeof(u.u_rlimit)); 
	bcopy( uptr->u_comm,    kptr->ui_comm,   sizeof(u.u_comm)); 

	kptr->ui_start  = uptr->u_start;
	kptr->ui_ru	= uptr->u_ru;
	kptr->ui_cru	= uptr->u_cru;
	kptr->ui_tsize	= uptr->u_tsize;
	kptr->ui_ttyp	= *uptr->u_ttyp;
	kptr->ui_ttyd	= uptr->u_ttyd;
	kptr->ui_ttympx	= uptr->u_ttympx;

	sreg_priv	= uptr->u_adspace.srval[PRIVSEG];
	sreg_text	= uptr->u_adspace.srval[TEXTSEG];

   	kptr->ui_luid 	= credentials.cr_luid;
   	kptr->ui_uid  	= credentials.cr_uid;
   	kptr->ui_gid  	= credentials.cr_gid;

	/* # of page frames in use (priv) */
   	kptr->ui_drss 	= vms_rusage(sreg_priv);  

	/* # of page frames in use (text) */
   	kptr->ui_trss 	= vms_rusage(sreg_text);  

	/* # of pageSpace blocks in use   */
   	kptr->ui_dvm  	= vms_psusage(sreg_priv); 

   	/* get percentage of active real memory */
   	machine_frames 	= vmker.nrpages - vmker.badpages - vmker.numfrb;
   	proc_frames    	= kptr->ui_drss + kptr->ui_trss;
   	kptr->ui_prm   	= (machine_frames == 0) ? 0 :
                    		(proc_frames * 1000 / machine_frames + 5) / 10;
}
