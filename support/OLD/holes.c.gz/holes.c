#include <stdio.h>
#include <sys/types.h>
#include <fcntl.h>

main(int argc, char *argv[])
{
	char buf[512];
	int fd, i;

	for (i = 0; i < sizeof(buf); i++) {
	    buf[i] = (char)(i & 0xff);
	}
	if ((fd = open64("xxx", O_RDWR|O_CREAT, 0600)) < 0) {
	    perror("open64");
	    return(1);
	}
	if (lseek64(fd, 0, SEEK_SET) < 0) {
	    perror("lseek->0");
	    return(1);
	}
	if (write(fd, buf, sizeof(buf)) != sizeof(buf)) {
	    perror("write1");
	    return(1);
	}
	if (lseek64(fd, 3000000000L, SEEK_SET) < 0) {
	    perror("lseek->3000000000L");
	    return(1);
	}
	if (write(fd, buf, sizeof(buf)) != sizeof(buf)) {
	    perror("write2");
	    return(1);
	}
	if (close(fd)) {
	    perror("close");
	    return(1);
	}
	return(0);
}
