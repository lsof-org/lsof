/*	ubulb.c		850921		*/

/*	Ubulb tests sockets: stream connected sockets in the Unix
 *	domain.
 *
 *	Ubulb does its job by providing a complete client/server pair in
 *	one invocation.  Ubulb may also be invoked separately to provide
 *	a separate client and a separate server.
 *
 *	After the client and server have established a connection, they
 *	exchange data.  The client accepts data from its standard input
 *	stream and sends it to the server, which echoes the data to its
 *	standard output stream.  The client prompts for input with a
 *	prompt string, "Server < ", received from the server; the
 *	server identifies data received from the client with the prefix
 *	"Client > ".
 *
 *	The connection may be broken by terminating the client or by
 *	supplying an EOF (^D) to its standard input.
 *
 *	Compile with -lsocket.
 *
 *	V. Abell, Purdue University Computing Center
 */

/*	Contains:
 *
 *	main()		- the main program
 *
 *	Exit()		- clean up and exit
 *
 *	Perror()	- call perror() and exit
 *
 *	startclient()	- start a client
 *
 *	usage()		- report usage and exit
 */

/*	Usage:
 *
 *	bulb [-c] [-h host] [-p port] [-s]
 *
 *	-c		run only the client
 *
 *	-n name		Unix domain socket name
 *			Default Unix_domain_socket
 *
 *	-s		run only the server
 *
 * Note: "-h host" and "-p port" are meaningful only when "-c"
 *	 is specified.
 */

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/un.h>


/*
 * Externals
 */

int	 errno;			/* error number from perror.c */


/*
 * Local incantations
 */

#define CPREFIX		"Client > "	/* client data prefix */
#define	MXLL		256		/* maximum line length */
#define SPROMPT		"Server < "	/* server prompt */
#define UNIXSNM		"Unix_domain_socket"


/*
 * Globals
 */

int Asock;			/* accept socket address */
int Csock;			/* connect socket address */
int Lsock;			/* listen socket FD */
struct sockaddr_un Ua;		/* Unix socket address */
char *Uname = UNIXSNM;	/* Unix socket name */


/*
 * main(argc, argv) - the main function
 */

main(argc, argv)
		int	 argc;
		char	*argv[];
{
		char	*a;			/* argument pointer */
struct	sockaddr_un	 aad;			/* accept address */
		int	 ax;			/* argument index */
		char	 buf[MXLL];		/* line buffer */
		int	 client = 1;		/* client status */
		int	 fd[2];			/* socketpair fd's */
register	int	 len;			/* length */
		int	 pid;			/* child process ID */
		int	 nl;			/* name length */
register	int	 pl;			/* prompt length */
		int	 server = 1;		/* server status */

/*
 * Process arguments.
 */

	if (argc > 1) {
		for (ax = 1; ax < argc; ax++) {
			a = argv[ax];
			if (*a != '-')
				usage();
			switch (*(a+1)) {

			case 'c':
				client = 1;
				server = 0;
				break;

			case 'n':
				if (++ax >= argc)
					usage();
				Uname = argv[ax];
				break;

			case 's':
				client = 0;
				server = 1;
				break;
			}
		}
	}
/*
 * Get a socket for the server and bind the local address.
 *
 * Then listen for a connection.
 */
	(void) memset((char *)&Ua, 0, sizeof(Ua));
	Ua.sun_family = AF_UNIX;
	(void) strcpy(Ua.sun_path, Uname);
	if (socketpair(AF_UNIX, SOCK_STREAM, 0, fd) == -1)
		Perror("socketpair");
	if ((pid = fork()) < 0)
		Perror("Server fork()");
	if (pid == 0) {
		(void) close(fd[0]);
		startclient(fd[1]);
		(void) fprintf(stderr,
			"Client exited unexpectedly.");
		Exit(1);
	}
	(void) close(fd[1]);
	Asock = fd[0];
/*
 * Accept a connection from a client.
 */
/*
 * Send SPROMPT to the client, then echo what is received from
 * the client to the standard output stream.
 */
	for (pl = strlen(SPROMPT);;) {
		if (write(Asock, SPROMPT, pl) != pl)
			Perror("Server write()");
		if ((len = read(Asock, buf, sizeof(buf))) <= 0) {
			if (len < 0)
				Perror("Server read()");
			(void) printf("Server: connection closed.\n");
			Exit(0);
		}
		if (len == sizeof(buf))
			buf[len-1] = '\0';
		else
			buf[len] = '\0';
		(void) printf("Client > %s", buf);
		if (strrchr(buf, '\n') == NULL)
			(void) printf("\n");
		(void) fflush(stdout);
	}

/* NOTREACHED */

}


/*
 * Exit(s)  - clean up and exit
 *
 * entry:
 *	Asock = server accept socket
 *	Csock = client socket
 *	Lsock = listen socket
 *	s     = exit status
 */

Exit(s)
		int	 s;
{
	if (Csock >= 0) {
		(void) shutdown(Csock, 2);
		(void) close(Csock);
	}
	if (Asock >= 0)
		(void) close(Asock);
	if (Lsock >= 0)
		(void) close(Lsock);
	exit(s);
}


/*
 * Perror(s) - call perror() and exit
 *
 * entry:
 *	s = pointer to perror() argument string
 */

Perror(s)
		char	*s;
{
	perror(s);
	Exit(1);
}


/*
 * startclient(cad) - start a client
 *
 * entry:
 *	cad    = pointer to connection address
 *	Myad   = this machine's socket address
 */

startclient(fd)
	int fd;				/* socketpair descriptor for child */
{
		char	 buf[MXLL];	/* line buffer */
register	int	 len;		/* line length */

/*
 * After each prompt is received from the remote client,
 * send the next line from the standard input stream.
 */
	Csock = fd;
	(void) clearerr(stdin);	/* DEBUG */
	for (errno = 0;;) {
		if ((len = read(Csock, buf, sizeof(buf))) <= 0) {
			if (errno != 0)
				Perror("Client read()");
			(void) fprintf(stderr, "Client: server sent EOF.\n");
			break;
		}
		if (len == sizeof(buf))
			buf[len-1] = '\0';
		else
			buf[len] = '\0';
		(void) printf("%s", buf);
		(void) fflush(stdout);
		if (fgets(buf, sizeof(buf), stdin) == NULL)
			break;
		len = strlen(buf);
		if (write(Csock, buf, len) < 0)
			Perror("Client write()");
		if (len == 0 || buf[len-1] != '\n') {
			if (write(Csock, "\n", 1) < 0)
				Perror("Client write()");
		}
	}
/* DEBUG
	if (ferror(stdin) != 0) {
		(void) fprintf(stderr, "Client: stdin ended with an error.\n");
		Exit(1);
	}
DEBUG */
	(void) printf("^D\nClient: EOF received on stdin.\n");
	Exit(0);

/* NOTREACHED */

}




/*
 * usage() - report usage and exit
 */

usage()

{
	(void) fprintf(stderr,
	    "ubulb usage: [-c] [-n Unix domain socket name] [-s]\n");
	Exit(1);
}
