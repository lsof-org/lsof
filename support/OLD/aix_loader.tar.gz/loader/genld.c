#ifndef _KERNEL
#define _KERNEL
#endif

#include <stdio.h>
#include <nlist.h>
#include <fcntl.h>
#include <ctype.h>
#include <errno.h>
#include <sys/proc.h>
#include <sys/user.h>
#include <sys/types.h>
#include <sys/malloc.h>
#include <sys/ldr.h>
#include <sys/syspest.h>
#include "ld_data.h"
#ifdef NETLS
#include "perfnetls.h"
#endif

#define KXSRVALSYMNAME  "g_kxsrval"
#define KXSRVALINDEX    0
#define PROCSYMNAME     "proc"
#define PROCINDEX       1
#define PROCCBSYMNAME  "proc_cb"
#define PROCCBINDEX    2
#define PROCOFFSETMASK(x) ((int)(x) & 0x0fffffff | 0x70000000)
#define USERSYMNAME	"__ublock"
#define USERINDEX   0
#define USEROFFSETMASK(x)	((x) & 0x0fffffff)

unsigned long User_offset;
unsigned long G_kxsrval;
unsigned long Proc_offset;
unsigned long Max_proc_value;
unsigned long Cur_offset;
unsigned long Shrlib_srval;

void pr_u ();
void pr_p ();
void main ();
void open_proc_tbl();
int get_next_proc();
int get_specific_proc();
void open_user_tbl();
void get_user_tbl_ent();
void random_read();


void main (int argc, char *argv[])
{
	long tmp, fd;
	int rt;
	struct user user;
	struct proc p;
	struct nlist nl[] = {
		{"library_anchor"},
		{"library_data_handle"},
		{NULL}
	};

#ifdef NETLS
	perf_netls_check();	/* do nls checking */
#endif /* NETLS */

	bzero(&user, sizeof (struct user));
	bzero(&p, sizeof (struct proc));

	if((fd = open("/dev/mem", O_RDONLY)) == -1)
	{
		perror ("Cannot open /dev/mem\n");
		exit(2);
	}

	/*
	 * Is /unix the current running kernel?
	 */
	rt = check_unix_file("/unix");
	if(rt ==  0 || rt == -2 ) {
		fprintf(stderr, "%s does not match the running kernel\n",
			  "/unix");
		fprintf(stderr, "Cannot obtain valid kernel addresses.\n");
		exit(1);
	}
	else if(rt == -1){    
		  exit(1);
	}
	
	nlist("/unix",nl);
	if (nl[0].n_value == 0 || nl[1].n_value == 0){
		fprintf(stderr, "nlist failed for name list\n");
		exit(1);
	}
	random_read(fd, &Shrlib_srval, sizeof(long), nl[1].n_value&0x0fffffff, 0);

	open_user_tbl(fd);
	open_proc_tbl (fd);

	while (get_next_proc(fd, &p) == 0)
	{
		if (p.p_stat == SNONE) continue;
		if (p.p_stat == SZOMB) continue;

		pr_p (p);

		get_user_tbl_ent(fd, &p, &user);

		pr_u (fd, user, p);

		bzero(&p, sizeof (struct proc));
		bzero(&user, sizeof (struct user));
	}
	exit(0);
}

void pr_u (long fd, struct user user, struct proc p)
{
	struct loader_entry buff2, *ptr;
	char buff1[40];
	int i, j;

	if (p.p_pid)
		printf ("Proc_name: %s\n", user.U_comm);
	else
		printf ("Proc_name: swapper\n");

	ptr = (struct loader_entry *) user.U_loader[0];
	while ( ptr != NULL )
	{
		lseek (fd, (long) ptr & 0x0fffffff, 0);
		readx (fd, &buff2, sizeof (buff2), p.p_adspace);
		
		if (((int) buff2.le_file & 0xf0000000) == 0xd0000000)
		{
			printf ("\t\t\t\t\t%x  ", (int)buff2.le_file);
			random_read(fd, buff1, sizeof(buff1), (int)buff2.le_filename&0x0fffffff,
					Shrlib_srval);
			i = strlen (buff1); 
			printf ("%s/", &buff1[i+1]); 
			printf ("%s\n", buff1); 
		}
		else{
			if (((int) buff2.le_file & 0xf0000000) == 0x10000000){
				lseek (fd, (long) buff2.le_filename & 0x0fffffff, 0);
				readx (fd, buff1, sizeof(buff1), p.p_adspace);
				printf ("\t\t\t\t\t%x  ", (int)buff2.le_file);
				printf ("%s\n", buff1);
			}
		}
		ptr = buff2.le_next;
	}
	printf("\n");
}


void pr_p (struct proc p)
{
	printf ("Proc_pid: %8ld\t",p.p_pid);
}

void open_proc_tbl(memfd)
int memfd;
{
	int exit_flag = 0;
	struct pm_heap proc_cb;
	int i;
	static struct nlist nl[] = {
		{KXSRVALSYMNAME},
		{PROCSYMNAME},
		{PROCCBSYMNAME},
		{NULL}
	};	

	if (nlist("/unix", nl) < 0)
	{
		perror("nlist:");
		exit(1);
	}

	for (i = 0;  nl[i].n_name;  i++)
		if (nl[i].n_value == 0)
		{
			/* couldn't find name of interest */
			fprintf(stderr, 
			    "nlist could not locate %s\n.", nl[i].n_name);
			exit_flag = 1;
		}
	if (exit_flag)
		exit(1);


	/* get kernel extension segment register value */
	random_read(memfd, &G_kxsrval, sizeof(G_kxsrval),
	    nl[KXSRVALINDEX].n_value, 0);

	/* get address of proc */
	Proc_offset = PROCOFFSETMASK(nl[PROCINDEX].n_value);

	/* get value of max_proc */
	random_read(memfd, &proc_cb, sizeof(proc_cb),
	    nl[PROCCBINDEX].n_value, 0); 

	Max_proc_value = PROCOFFSETMASK(proc_cb.highwater); 

	/* initialize current offset */
	Cur_offset = Proc_offset;
}

int get_next_proc(memfd, proc)
int memfd;
struct proc *proc;
{
	if (Cur_offset >= Max_proc_value)
		/* proc table is completely scanned */
		return(-1);
	else
	{
		/* read proc table entry */
		random_read(memfd, proc, sizeof(*proc), Cur_offset, G_kxsrval);

		/* increment pointer into proc table for next time */
		Cur_offset = PROCOFFSETMASK(Cur_offset + sizeof(struct proc));

		/* successful */
		return(0);
	}
}

int get_specific_proc(memfd, pid, proc)
int memfd;
int pid;
struct proc *proc;
{
	unsigned long offset;

	/* calculate offset of proc table entry */
	offset = PROCOFFSETMASK(Proc_offset + 
	    PROCMASK(pid) * sizeof(struct proc));

	if (offset < Proc_offset || offset >= Max_proc_value)
		/* entry is not within table */
		return(-1);
	else
	{
		/* read proc table entry */
		random_read(memfd, proc, sizeof(*proc), offset, G_kxsrval);

		if (proc->p_stat != SNONE && proc->p_pid == pid)
			/* successful */
			return(0);
		else
			/* process with pid was not found */
			return(-1);
	}
}

void open_user_tbl(memfd)
int memfd;
{
	struct ublock *ublk;
	static struct nlist nl[] = {
		{USERSYMNAME},
		{NULL},
	};

	if (knlist(nl, 1, sizeof(struct nlist)) < 0)
	{
		perror("knlist:");
		exit(1);
	}

	if (nl[USERINDEX].n_value == 0)
	{
		/* couldn't find name of interest */
		fprintf(stderr,
		    "nlist could not locate %s\n", nl[USERINDEX].n_name);
		exit(1);
	}
	   
    ublk = (struct ublock *)nl[USERINDEX].n_value;
	User_offset = &(ublk->ub_user);
	User_offset = USEROFFSETMASK(User_offset); 

}


void get_user_tbl_ent(memfd, proc, user)
int memfd;
struct proc *proc;
struct user *user;
{
	random_read(memfd, user, sizeof(*user), User_offset, 
	    proc->p_adspace);
}


void random_read(fd, buf, size, offset, ext)
int fd, ext;
char *buf;
unsigned int size;
long offset;
{
	long lseek();

	if (lseek(fd, offset, SEEK_SET) < 0)
	{
		perror("lseek");
		exit(1);
	}
	if (readx(fd, buf, size, ext) != size)
	{
		perror("READ");
		exit(1);
	}
}
