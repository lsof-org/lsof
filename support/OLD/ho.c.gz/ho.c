#include <stdio.h>
#include <fcntl.h>

main(int argc, char *argv[])
{
	int ac;

	for (ac = 1; ac < argc; ac++) {
		if (open(argv[ac], O_RDONLY, 0) < 0) {
			perror(argv[ac]);
			exit(1);
		}
	}
	sleep(3600);
	exit(0);
}
