#include <stdio.h>
#include <fcntl.h>

extern int errno;

main(argc, argv)
	int argc;
	char *argv[];
{
	char buf[32];
	int fd, i, n;

	n = atoi(argv[1]);
	for (i = 0; i < n; i++) {
		(void) sprintf(buf, "manyf_%0d", i);
		if ((fd = open(buf, O_RDWR|O_CREAT|O_EXCL, 0600)) < 0) {
			perror(buf);
			exit(1);
		}
		fprintf(stderr, "opened %s, fd = %d\n", buf, fd);
	}
	if (fcntl(fd, F_SETFD, 1) == -1 ) {
	    fprintf(stderr, "%s F_SETFD: %s\n", buf, strerror(errno));
	    exit(1);
	}
	fprintf(stderr, "PID %d: %d files open; sleeping 3600 sec.\n",
		getpid(), n);
	sleep(3600);
	exit(0);
}
